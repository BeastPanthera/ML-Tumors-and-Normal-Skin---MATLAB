% ------------------------------------------------------------
%-------------------------------------------------------------
clc
close all
clear all;
%-------------------------------------------------------------

% Load training features and labels
[y_train, x_train] = libsvmread('train.txt');
[y_test, x_test] = libsvmread('test.txt');
x_test_NN = full(x_test);
x_train_NN = full(x_train);


x_train_NN_new = [];
for j = 1:length(x_train_NN)
    temp = 0; %variable for making sure the highest number is stored
    temp_index = 0; %variable for indexing
    for i = 1:8
        if x_train_NN(j,i) > 0 %if the row,column value is greater
           x_train_NN_new(j,i) = 1; 
        else
            x_train_NN_new(j,i) = 0;
        end
    end
end

x_test_NN_new = [];
for j = 1:length(x_test_NN)
    temp = 0; %variable for making sure the highest number is stored
    temp_index = 0; %variable for indexing
    for i = 1:8
        if x_test_NN(j,i) > 0 %if the row,column value is greater
           x_test_NN_new(j,i) = 1; 
        else
            x_test_NN_new(j,i) = 0;
        end
    end
end

P = x_train_NN_new';
T = y_train';
P_test = x_test_NN_new';
T_test = y_test';

net = linearlayer(0,100);
net = configure(net,P,T);
%net.IW{1}(1,8);
%net.b{1};

[net,a,e,pf] = adapt(net,P,T); % optimizing parameters of model
net = train(net,P,T);

predict_train = sim(net, P);
predict_test = sim(net, P_test);

figure(1);
plotconfusion(T_test,predict_test) %Confusion matrix of test data
title("Confusion Matrix for Test Data")

figure(2);
plotconfusion(T,predict_train) %Confusion matrix of test data
title("Confusion Matrix for Train Data")