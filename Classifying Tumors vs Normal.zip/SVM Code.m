% ------------------------------------------------------------
%-------------------------------------------------------------
clc
close all
clear all;

% Load training features and labels
[y_train, x_train] = libsvmread('train.txt');
[y_test, x_test] = libsvmread('test.txt');

% Train the model and get the primal variables w, b from the model
% Libsvm options
% -s 0 : classification
% -t 0 : linear kernel
% -c somenumber : set the cost

%-------------------------------------------
%Question 1, Part b:
disp('Information of the SVM model for a linear kenel type:')
model1 = svmtrain(y_train, x_train, sprintf('-s 0 -t 0 '));
%This model has the kernel type set as linear
[predicted_label_linear_train, accuracy_linear_train, decision_values_linear_train] = svmpredict(y_train, x_train, model1);

disp('Train Accuracy of linear kernel model type:')
disp(accuracy_linear_train)

[predicted_label_linear, accuracy_linear, decision_values_linear] = svmpredict(y_test, x_test, model1);

disp('Test Accuracy of linear kernel model type:')
disp(accuracy_linear)

disp('Information of the SVM model for a polynomial kenel type:')
model2 = svmtrain(y_train, x_train, sprintf('-s 0 -t 1 '));
%This model has the kernel type set as polynomial
[predicted_label_polynomial_train, accuracy_polynomial_train, decision_values_polynomial_train] = svmpredict(y_train, x_train, model2);

disp('Train Accuracy of polynomial kernel model type:')
disp(accuracy_polynomial_train)

[predicted_label_polynomial, accuracy_polynomial, decision_values_polynomial] = svmpredict(y_test, x_test, model2);

disp('Test Accuracy of polynomial kernel model type:')
disp(accuracy_polynomial)

disp('Information of the SVM model for a radial basis (Gaussian) kenel type:')
model3 = svmtrain(y_train, x_train, sprintf('-s 0 -t 2 '));
%This model has the kernel type set as radial basis (Gaussian)
[predicted_label_gaussian_train, accuracy_gaussian_train, decision_values_gaussian_train] = svmpredict(y_train, x_train, model3);

disp('Train Accuracy of radial basis (Gaussian) kernel model type:')
disp(accuracy_gaussian_train)

[predicted_label_gaussian, accuracy_gaussian, decision_values_gaussian] = svmpredict(y_test, x_test, model3);

disp('Test Accuracy of radial basis (Gaussian) kernel model type:')
disp(accuracy_gaussian)

disp('Information of the SVM model for a Sigmoid kenel type:')
model4 = svmtrain(y_train, x_train, sprintf('-s 0 -t 3 '));
%This model has the kernel type set as Sigmoid

[predicted_label_sigmoid_train, accuracy_sigmoid_train, decision_values_sigmoid_train] = svmpredict(y_train, x_train, model4);

disp('Train Accuracy of Sigmoid kernel model type:')
disp(accuracy_sigmoid_train)

[predicted_label_sigmoid, accuracy_sigmoid, decision_values_sigmoid] = svmpredict(y_test, x_test, model4);

disp('Test Accuracy of Sigmoid kernel model type:')
disp(accuracy_sigmoid)

%---------------------------------------
%Question 1, Part c
C_1 = 1;
gamma_1 = 10000;
model5 = svmtrain(y_train, x_train, sprintf('-s 0 -t 2 -g %g -c %g', gamma_1, C_1));
[predicted_label_m1, accuracy_m1, decision_values_m1] = svmpredict(y_test, x_test, model5);
disp('Test Accuracy when C = 1 & gamma = 10000, Gaussian Model:')
disp(accuracy_m1)

[predicted_label_m1_t, accuracy_m1_t, decision_values_m1_t] = svmpredict(y_train, x_train, model5);
disp('Train Accuracy when C = 1 & gamma = 10000, Gaussian Model:')
disp(accuracy_m1_t)

C_2 = 2000;
gamma_2 = 10;
model6 = svmtrain(y_train, x_train, sprintf('-s 0 -t 2 -g %g -c %g', gamma_2, C_2));
[predicted_label_m2, accuracy_m2, decision_values_m2] = svmpredict(y_test, x_test, model6);
disp('Test Accuracy when C = 2000 & gamma = 10, Gaussian Model:')
disp(accuracy_m2)

[predicted_label_m2_t, accuracy_m2_t, decision_values_m2_t] = svmpredict(y_train, x_train, model6);
disp('Train Accuracy when C = 2000 & gamma = 10, Gaussian Model:')
disp(accuracy_m2_t)

%-------------------------------------------------------
%Question 1, part d
accuracy_stored = 0;
c_stored = 0;
g_stored = 0;

g_testing = [];
c_testing = [];
accuracy_testing = [];
counter = 1;
for g_range = 0.1:0.5:10
    for c_range = 0.1:0.1:2
        model_optimal = svmtrain(y_train, x_train, sprintf('-s 0 -t 2 -g %g -c %g', g_range, c_range));
        [predicted_label_opt, accuracy_opt, decision_values_opt] = svmpredict(y_test, x_test, model_optimal);
        accuracy_testing(1,counter) = accuracy_opt(1,1);
        c_testing(1,counter) = c_range;
        g_testing(1,counter) = g_range;
        counter = counter + 1;
        if accuracy_opt(1,1) > accuracy_stored
            accuracy_stored = accuracy_opt;
            g_stored = g_range;
            c_stored = c_range;
        end
    end
end

disp("The best g, gamma value is:")
disp(g_stored)

disp('The best c, cost value is:')
disp(c_stored)

disp('This gives the accuracy of:')
disp(accuracy_stored)

figure;
plot3(g_testing,c_testing,accuracy_testing)
xlabel('g value')
ylabel('c value')
zlabel('accuracy(%)')

