% ------------------------------------------------------------
%-------------------------------------------------------------
clc
close all
clear all;
%-------------------------------------------------------------
%Question 2, Part b:
Strong_p_data = csvread('Strong p-values data normal & tumor.csv');
%Picked 10 rows that show strong (small) p-values and put them into .csv
%file
s_p_features_train = Strong_p_data(:,1);
s_p_labels_train = Strong_p_data(:,2);

model1 = svmtrain(s_p_labels_train, s_p_features_train, sprintf('-s 0 -t 0 '));
%Linear Model

model2 = svmtrain(s_p_labels_train, s_p_features_train, sprintf('-s 0 -t 2 '));

%Question 2, Part c:

%The code will follow the leave 1 out strategy below:
s_p_f_train_leave1out = Strong_p_data(1:359,1);
s_p_l_train_leave1out = Strong_p_data(1:359,2);
s_p_f_test_leave1out = Strong_p_data(360,1);
s_p_l_test_leave1out = Strong_p_data(360,2);

model_leave1out_linear = svmtrain(s_p_l_train_leave1out, s_p_f_train_leave1out, sprintf('-s 0 -t 0 '));

[predicted_leave1out_linear, accuracy_leave1out_linear, decision_values_leave1out_linear] = svmpredict(s_p_l_test_leave1out, s_p_f_test_leave1out, model_leave1out_linear);

model_leave1out_gaussian = svmtrain(s_p_l_train_leave1out, s_p_f_train_leave1out, sprintf('-s 0 -t 2 '));

[predicted_leave1out_gaussian, accuracy_leave1out_gaussian, decision_values_leave1out_gaussian] = svmpredict(s_p_l_test_leave1out, s_p_f_test_leave1out, model_leave1out_gaussian);

%The code will follow the leave 10 out strategy below:
s_p_f_train_leave10out_t = Strong_p_data(1:175,1);
s_p_l_train_leave10out_t = Strong_p_data(1:175,2);
s_p_f_train_leave10out_N = Strong_p_data(186:360,1);
s_p_l_train_leave10out_N = Strong_p_data(186:360,2);

s_p_f_train_leave10out = s_p_f_train_leave10out_t + s_p_f_train_leave10out_N;
s_p_l_train_leave10out = s_p_l_train_leave10out_t + s_p_l_train_leave10out_N;

s_p_f_test_leave10out = Strong_p_data(176:185,1);
s_p_l_test_leave10out = Strong_p_data(176:185,2);

model_leave10out_linear = svmtrain(s_p_l_train_leave10out, s_p_f_train_leave10out, sprintf('-s 0 -t 0 '));

[predicted_leave10out_linear, accuracy_leave10out_linear, decision_values_leave10out_linear] = svmpredict(s_p_l_test_leave10out, s_p_f_test_leave10out, model_leave10out_linear);

model_leave10out_gaussian = svmtrain(s_p_l_train_leave10out, s_p_f_train_leave10out, sprintf('-s 0 -t 2 '));

[predicted_leave10out_gaussian, accuracy_leave10out_gaussian, decision_values_leave10out_gaussian] = svmpredict(s_p_l_test_leave10out, s_p_f_test_leave10out, model_leave10out_gaussian);

%The cross-validation outputs are the following:

disp('Strong p value Accuracy of linear kernel model doing cross-validation with the leave-1-out strategy:')
disp(accuracy_leave1out_linear)

disp('Strong p value Accuracy of Non-linear (Gaussian) kernel model doing cross-validation with the leave-1-out strategy:')
disp(accuracy_leave1out_gaussian)

disp('Strong p value Accuracy of linear kernel model doing cross-validation with the leave-10-out strategy:')
disp(accuracy_leave10out_linear)

disp('Strong p value Accuracy of Non-linear (Gaussian) kernel model doing cross-validation with the leave-10-out strategy:')
disp(accuracy_leave10out_gaussian)

%Question 2, Part f...Repeating parts b-d:
Weak_p_data = csvread('Weak p-values data normal & tumor.csv');

%Picked 10 rows that show strong (small) p-values and put them into .csv
%file
w_p_features_train = Weak_p_data(:,1);
w_p_labels_train = Weak_p_data(:,2);

model3 = svmtrain(w_p_labels_train, w_p_features_train, sprintf('-s 0 -t 0 '));
%Linear Model

model4 = svmtrain(w_p_labels_train, w_p_features_train, sprintf('-s 0 -t 2 '));

%The code will follow the leave 1 out strategy below:
w_p_f_train_leave1out = Weak_p_data(1:359,1);
w_p_l_train_leave1out = Weak_p_data(1:359,2);
w_p_f_test_leave1out = Weak_p_data(360,1);
w_p_l_test_leave1out = Weak_p_data(360,2);

model_leave1out_linear_w = svmtrain(w_p_l_train_leave1out, w_p_f_train_leave1out, sprintf('-s 0 -t 0 '));

[predicted_leave1out_linear_w, accuracy_leave1out_linear_w, decision_values_leave1out_linear_w] = svmpredict(w_p_l_test_leave1out, w_p_f_test_leave1out, model_leave1out_linear_w);

model_leave1out_gaussian_w = svmtrain(w_p_l_train_leave1out, w_p_f_train_leave1out, sprintf('-s 0 -t 2 '));

[predicted_leave1out_gaussian_w, accuracy_leave1out_gaussian_w, decision_values_leave1out_gaussian_w] = svmpredict(w_p_l_test_leave1out, w_p_f_test_leave1out, model_leave1out_gaussian_w);

%The code will follow the leave 10 out strategy below:
w_p_f_train_leave10out_t = Weak_p_data(1:175,1);
w_p_l_train_leave10out_t = Weak_p_data(1:175,2);
w_p_f_train_leave10out_N = Weak_p_data(186:360,1);
w_p_l_train_leave10out_N = Weak_p_data(186:360,2);

w_p_f_train_leave10out = w_p_f_train_leave10out_t + w_p_f_train_leave10out_N;
w_p_l_train_leave10out = w_p_l_train_leave10out_t + w_p_l_train_leave10out_N;

w_p_f_test_leave10out = Weak_p_data(176:185,1);
w_p_l_test_leave10out = Weak_p_data(176:185,2);

model_leave10out_linear_w = svmtrain(w_p_l_train_leave10out, w_p_f_train_leave10out, sprintf('-s 0 -t 0 '));

[predicted_leave10out_linear_w, accuracy_leave10out_linear_w, decision_values_leave10out_linear_w] = svmpredict(w_p_l_test_leave10out, w_p_f_test_leave10out, model_leave10out_linear_w);

model_leave10out_gaussian_w = svmtrain(w_p_l_train_leave10out, w_p_f_train_leave10out, sprintf('-s 0 -t 2 '));

[predicted_leave10out_gaussian_w, accuracy_leave10out_gaussian_w, decision_values_leave10out_gaussian_w] = svmpredict(w_p_l_test_leave10out, w_p_f_test_leave10out, model_leave10out_gaussian_w);

%The cross-validation outputs are the following:

disp('Weak p value Accuracy of linear kernel model doing cross-validation with the leave-1-out strategy:')
disp(accuracy_leave1out_linear_w)

disp('Weak p value Accuracy of Non-linear (Gaussian) kernel model doing cross-validation with the leave-1-out strategy:')
disp(accuracy_leave1out_gaussian_w)

disp('Weak p value Accuracy of linear kernel model doing cross-validation with the leave-10-out strategy:')
disp(accuracy_leave10out_linear_w)

disp('Weak p value Accuracy of Non-linear (Gaussian) kernel model doing cross-validation with the leave-10-out strategy:')
disp(accuracy_leave10out_gaussian_w)